import 'package:flutter/material.dart';
import '../global_config.dart';
import '../index/index.dart';

class LoginScreen extends StatefulWidget {
  createState() => LoginState();
}

class LoginState extends State {
  String account="";
  String password="";

  build(BuildContext context) {
    return new MaterialApp(
        home: Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Text(
                    "White",
                    style: TextStyle(
                        fontFamily: "Oswald",
                        fontSize: 80,
                        color: Colors.white70
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.all(10),
                    child: TextField(
                        autofocus: true,
                        decoration: InputDecoration(
                            labelText: "账号",
                            hintText: "输入手机号或邮箱",
                            prefixIcon: Icon(Icons.person)
                        ),
                        onChanged: (v) {
                          account = v;
                        }
                    ),),
                  Padding(
                    padding: EdgeInsets.all(10),
                    child: TextField(
                        decoration: InputDecoration(
                            labelText: "密码",
                            hintText: "输入密码",
                            prefixIcon: Icon(Icons.lock)
                        ),
                        obscureText: true,
                        onChanged: (v) {
                          password=v;
                        }
                    ),),
                  Padding(padding: EdgeInsets.only(top: 50),),
                  GestureDetector(
                    child: Container(
                      margin: EdgeInsets.all(10.0),
                      padding: EdgeInsets.all(10.0),
                      color: Colors.grey,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text("登陆",style: TextStyle(fontSize: 20),)
                        ],
                      ),
                    ),
                    onTap: (){
                      login();
                    }
                  )
                ],
              ),
            )),
        theme: GlobalConfig.themeData
    );



  }

  login() {
    Navigator.push( context,
        MaterialPageRoute(builder: (context) {
          return Index();
        }));
  }

}
